package com.example.test.services.Impl;

import com.example.test.model.Task;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

@Service
public class Que {
    private final ConcurrentLinkedQueue<Task> que;

    public Que() {
        this.que = new ConcurrentLinkedQueue<>();
    }

    public Task getTask() {
        return que.poll();
    }

    public boolean addTask(Task task) {
        return que.add(task);
    }

    public int getQueueSize() {
        return que.size();
    }

    public List<Task> get3Tasks() {
        synchronized (que) {
            if (getQueueSize() <= 3) {
                throw new RuntimeException();
            }
            return List.of(getTask(), getTask(), getTask());
        }
    }
}
