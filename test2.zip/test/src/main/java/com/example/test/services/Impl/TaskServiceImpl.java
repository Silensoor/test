package com.example.test.services.Impl;

import com.example.test.dto.StatusRs;
import com.example.test.dto.TaskRq;
import com.example.test.dto.TaskResponse;
import com.example.test.dto.TaskShortResponse;
import com.example.test.model.Task;
import com.example.test.repository.TaskRepository;
import com.example.test.services.TasksService;

import com.example.test.utils.Mapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import static com.example.test.utils.Mapper.taskModelToTaskResponse;
import static com.example.test.utils.Mapper.taskRequestToTaskModel;

@Service
public class TaskServiceImpl implements TasksService {

    private final TaskRepository taskRepository;
    private final Que que;
    private final ExecutorService executorService;

    public TaskServiceImpl(TaskRepository taskRepository, Que que) {
        this.taskRepository = taskRepository;
        this.que = que;
        this.executorService = Executors.newCachedThreadPool();
    }

    @Override
    public StatusRs addTask(TaskRq taskRq) {
        return new StatusRs(que.addTask(taskRequestToTaskModel(taskRq)));
    }

    @Override
    public StatusRs putTasksToDatabase() {
        try {
            List<Task> tasks = que.get3Tasks();
            tasks.forEach(task -> executorService.submit(() -> taskRepository.saveTasks(task)));
            return new StatusRs(true);
        } catch (RuntimeException e) {
            return new StatusRs(false);
        }
    }

    @Override
    public List<TaskShortResponse> getAllTasks() {
        return taskRepository.findAllTasksShort().stream().map(Mapper::taskModelToTaskShortResponse).collect(Collectors.toList());
    }

    @Override
    public TaskResponse getTaskById(int id) {
        return taskModelToTaskResponse(taskRepository.findById(id));
    }
}
