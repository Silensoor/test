package com.example.test.controllers;

import com.example.test.dto.TaskRq;
import com.example.test.dto.TaskResponse;
import com.example.test.dto.TaskShortResponse;
import com.example.test.services.TasksService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class TaskController {

    private final TasksService tasksService;

    @PostMapping(value = "/create", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> putInQueue(@RequestBody TaskRq taskRq) {
        return ResponseEntity.ok(tasksService.addTask(taskRq));
    }

    @PostMapping("/data")
    public ResponseEntity<?> addTasksToDatabase() {
        return ResponseEntity.ok(tasksService.putTasksToDatabase());
    }

    @GetMapping("/tasks")
    public ResponseEntity<List<TaskShortResponse>> getTasks() {
        return ResponseEntity.ok(tasksService.getAllTasks());
    }
    @GetMapping("/task")
    public ResponseEntity<TaskResponse> getTask(@RequestParam("id") Integer id){
        return ResponseEntity.ok(tasksService.getTaskById(id));
    }

}
